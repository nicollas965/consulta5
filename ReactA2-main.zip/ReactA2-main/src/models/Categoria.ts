export interface Categoria {
    nome: string;
    categoriaId?: string;
    criadoEm?: string;
}